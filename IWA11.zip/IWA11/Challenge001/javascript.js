const root1 = document.querySelector('[data-key="order1"]');

const  biscuits1 = document.querySelector('[data="biscuit1"]');
const donuts1 = document.querySelector('[data="donuts1"]');
const pancakes1= document.querySelector('[data="pancakes1"]');
const status1=document.querySelector('[data="status1"]');

const root2 = document.querySelector('[data-key="order2"]');
const biscuits2 =document.querySelector('[data="biscuit2"]');
const donuts2= document.querySelector('[data="donuts2"]');
const pancakes2=document.querySelector('[data="pancakes2"]');
const status2=document.querySelector('[data="status2"]');

const root3 = document.querySelector('[data-key="order3"]');

const biscuits3= document.querySelector('[data="biscuits3"]');
const donuts3 = document.querySelector('[data="donuts3"]');
const pancakes3 = document.querySelector('[data="pancakes3"]');
const status3= document.querySelector('[data="status3"]');

biscuits1 ; root1.biscuits
donuts1 ;root1.donuts;
pancakes1 ;root1.pancakes
status1; root2.status;

biscuits2; root2.biscuits;
donuts2 ;root2.donuts;
pancakes2 ;root2.pancakes;
status2 ;root2.status;


biscuits3; root3.biscuits;
donuts3 ; root3.donuts;
pancakes3 ;root3.pancakes;
status3;root3.status;